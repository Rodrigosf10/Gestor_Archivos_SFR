<?php
    session_start();
    require_once "../../clases/Conexion.php";
    $objeto = new Conectar();
    $conexion = $objeto->conexion();
    $idUsuario = $_SESSION['idUsuario'];
    $sql = "SELECT 
                archivos.id_archivo AS idArchivo, 
                usuario.nombre AS nombreUsuario, 
                categorias.nombre AS categoria, 
                archivos.nombre AS nombreArchivo, 
                archivos.tipo AS tipoArchivo,
                archivos.ruta AS rutaArchivo,
                archivos.fecha AS fecha
            FROM t_archivos AS archivos
                INNER JOIN t_usuarios AS usuario ON archivos.id_usuario = usuario.id_usuario
                INNER JOIN t_categorias AS categorias ON archivos.id_categoria = categorias.id_categoria
                AND archivos.id_usuario = '$idUsuario'";
    $result = mysqli_query($conexion, $sql);
?>


<div class="row">
    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table table-hover table-striped table-dark" id="tablaGestorDataTable">
                <thead class="thead-dark">
                    <tr style="text-align: center;">
                        <th style="text-align: center;">Categoria</th>
                        <th style="text-align: center;">Nombre</th>
                        <th style="text-align: center;">Extension / Tipo de Archivo</th>
                        <th style="text-align: center;">Descargar</th>
                        <th style="text-align: center;">Visualizar</th>
                        <th style="text-align: center;">Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $extensionesValidas = array('png','jpg','pdf','mp3','mp4'); /*Arreglo de extensiones Validas*/
                    while($mostrar = mysqli_fetch_array($result)){
                        $rutaDescarga = "../archivos/".$idUsuario."/".$mostrar['nombreArchivo'];
                        $nombreArchivo = $mostrar['nombreArchivo'];
                        $idArchivo = $mostrar['idArchivo'];
                ?>
                    <tr style="text-align: center;">
                        <td style="text-align: center;"><?php echo $mostrar['categoria']; ?></td>
                        <td style="text-align: center;"><?php echo $mostrar['nombreArchivo']; ?></td>
                        <td style="text-align: center;"><?php echo $mostrar['tipoArchivo']; ?></td>
                        <td style="text-align: center;">
                            <a href="<?php echo $rutaDescarga; ?>" download="<?php echo $nombreArchivo; ?>" class="btn btn-secondary">
                                <span class="fas fa-download"></span>  Descagar Archivo
                            </a>
                        </td>
                        <td style="text-align: center;">
                        <?php
                            for ($i=0; $i < count($extensionesValidas); $i++) { 
                                if($extensionesValidas){
                        ?>
                                <span class="btn btn-warning btn-sm" data-toggle="modal" data-target="#visualizarArchivo" onclick="obtenerArchivoPorId('<?php echo $idArchivo ?>')">
                                    <span class="fas fa-eye"></span>
                                </span>
                        <?php
                                }
                            }
                        ?>
                        </td>
                        <td style="text-align: center;">
                            <span class="btn btn-danger btn-sm" onclick="eliminarArchivo('<?php echo $idArchivo ?>')">
                                <span class="fas fa-skull-crossbones"></span>
                            </span>
                        </td>
                    </tr>
                <?php
                    }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        $('#tablaGestorDataTable').DataTable();
    });
</script>